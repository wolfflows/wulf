Sample configuration files for:
```
SystemD: bitcoind.service
Upstart: bitcoind.conf
OpenRC:  bitcoind.openrc
         bitcoind.openrcconf
CentOS:  bitcoind.init
OS X:    org.bitcoin.bitcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
